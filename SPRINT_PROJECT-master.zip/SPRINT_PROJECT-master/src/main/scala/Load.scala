
import org.apache.spark.sql.DataFrame
import java.util.Properties

object Load {
  val jdbcUrl = "jdbc:postgresql://localhost:5434/transportdb"
  val connectionProperties = new Properties()
  connectionProperties.setProperty("user", "postgres")
  connectionProperties.setProperty("password", "admin@123")
  connectionProperties.setProperty("driver", "org.postgresql.Driver")

  def writeToPostgres(df: DataFrame, tableName: String): Unit = {
    df.write.mode("overwrite").jdbc(jdbcUrl, tableName, connectionProperties)
  }
}
