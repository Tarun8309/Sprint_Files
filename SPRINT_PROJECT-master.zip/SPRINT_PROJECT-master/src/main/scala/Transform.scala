

import org.apache.spark.sql.{DataFrame, functions => F}

object Transform {
  def enrichData(df: DataFrame): DataFrame = {
    df.na.drop(Seq("capacity", "passengers", "occupancy_rate", "distance_km", "fare_per_passenger", "revenue", "fuel_consumed_liters"))
      .withColumn("km_per_liter", F.col("distance_km") / F.col("fuel_consumed_liters"))
      .withColumn("revenue_per_km", F.col("revenue") / F.col("distance_km"))
      .withColumn("load_factor", (F.col("passengers") / F.col("capacity")) * 100)
      .withColumn("trip_datetime", F.to_timestamp(F.col("date")))
      .withColumn("hour", F.hour(F.col("trip_datetime")))
      .withColumn("time_of_day",
        F.when(F.col("hour") < 6, "Night")
          .when(F.col("hour") < 12, "Morning")
          .when(F.col("hour") < 18, "Afternoon")
          .otherwise("Evening")
      )
  }
}
