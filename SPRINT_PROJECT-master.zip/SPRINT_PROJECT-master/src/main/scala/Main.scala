import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object APSRTC_ETL_Main_NoAlias {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder()
      .appName("APSRTC Modular ETL")
      .master("local[*]")
      .getOrCreate()

    val filePath = "data/APSRTC_Transport_Data.csv"
    val rawDF = Extract.extractData(spark, filePath)
    val enrichedDF = Transform.enrichData(rawDF)

    Load.writeToPostgres(enrichedDF, "enriched_transport_data")
    Load.writeToPostgres(enrichedDF.orderBy(desc("km_per_liter")).limit(5), "fuel_efficiency_top")
    Load.writeToPostgres(enrichedDF.orderBy(asc("km_per_liter")).limit(5), "fuel_efficiency_bottom")
    Load.writeToPostgres(enrichedDF.orderBy(desc("revenue_per_km")).limit(5), "revenue_per_km_top")
    Load.writeToPostgres(enrichedDF.orderBy(asc("revenue_per_km")).limit(5), "revenue_per_km_bottom")
    Load.writeToPostgres(enrichedDF.orderBy(desc("load_factor")).limit(5), "load_factor_top")
    Load.writeToPostgres(enrichedDF.orderBy(asc("load_factor")).limit(5), "load_factor_bottom")

    Load.writeToPostgres(
      enrichedDF.groupBy("day_of_week")
        .agg(avg("occupancy_rate").alias("avg_occupancy"))
        .orderBy(desc("avg_occupancy")),
      "peak_congestion_day"
    )

    Load.writeToPostgres(
      enrichedDF.groupBy("month")
        .agg(avg("occupancy_rate").alias("avg_occupancy"))
        .orderBy(desc("avg_occupancy")),
      "peak_congestion_month"
    )

    Load.writeToPostgres(
      enrichedDF.filter(col("occupancy_rate") < 50)
        .groupBy("route")
        .agg(avg("occupancy_rate").alias("avg_occupancy"))
        .orderBy("avg_occupancy")
        .limit(5),
      "underutilized_routes"
    )

    Load.writeToPostgres(
      enrichedDF.filter(col("occupancy_rate") > 90)
        .groupBy("route")
        .agg(avg("occupancy_rate").alias("avg_occupancy"))
        .orderBy(desc("avg_occupancy"))
        .limit(5),
      "overcrowded_routes"
    )

    println("Modular ETL pipeline completed and data written to PostgreSQL.")
    spark.stop()
  }
}
