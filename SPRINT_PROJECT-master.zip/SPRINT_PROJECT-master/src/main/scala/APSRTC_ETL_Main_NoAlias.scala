import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object APSRTC_ETL_Main_NoAlias {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder()
      .appName("APSRTC Modular ETL")
      .master("local[*]")
      .getOrCreate()

    val filePath = "data/APSRTC_Transport_Data.csv"
    val rawDF = Extract.extractData(spark, filePath)
    val enrichedDF = Transform.enrichData(rawDF)

    // Write full enriched data
    Load.writeToPostgres(enrichedDF, "enriched_transport_data")
    Load.writeToParquet(enrichedDF, "output/enriched_transport_data")

    // Fuel efficiency
    val topFuel = enrichedDF.orderBy(desc("km_per_liter")).limit(5)
    val bottomFuel = enrichedDF.orderBy(asc("km_per_liter")).limit(5)
    Load.writeToPostgres(topFuel, "fuel_efficiency_top")
    Load.writeToPostgres(bottomFuel, "fuel_efficiency_bottom")
    Load.writeToParquet(topFuel, "output/fuel_efficiency_top")
    Load.writeToParquet(bottomFuel, "output/fuel_efficiency_bottom")

    // Revenue per km
    val topRevenue = enrichedDF.orderBy(desc("revenue_per_km")).limit(5)
    val bottomRevenue = enrichedDF.orderBy(asc("revenue_per_km")).limit(5)
    Load.writeToPostgres(topRevenue, "revenue_per_km_top")
    Load.writeToPostgres(bottomRevenue, "revenue_per_km_bottom")
    Load.writeToParquet(topRevenue, "output/revenue_per_km_top")
    Load.writeToParquet(bottomRevenue, "output/revenue_per_km_bottom")

    // Load factor
    val topLoad = enrichedDF.orderBy(desc("load_factor")).limit(5)
    val bottomLoad = enrichedDF.orderBy(asc("load_factor")).limit(5)
    Load.writeToPostgres(topLoad, "load_factor_top")
    Load.writeToPostgres(bottomLoad, "load_factor_bottom")
    Load.writeToParquet(topLoad, "output/load_factor_top")
    Load.writeToParquet(bottomLoad, "output/load_factor_bottom")

    // Peak congestion by day
    val peakDay = enrichedDF.groupBy("day_of_week")
      .agg(avg("occupancy_rate").alias("avg_occupancy"))
      .orderBy(desc("avg_occupancy"))
    Load.writeToPostgres(peakDay, "peak_congestion_day")
    Load.writeToParquet(peakDay, "output/peak_congestion_day")

    // Peak congestion by month
    val peakMonth = enrichedDF.groupBy("month")
      .agg(avg("occupancy_rate").alias("avg_occupancy"))
      .orderBy(desc("avg_occupancy"))
    Load.writeToPostgres(peakMonth, "peak_congestion_month")
    Load.writeToParquet(peakMonth, "output/peak_congestion_month")

    // Underutilized routes
    val underutilized = enrichedDF.filter(col("occupancy_rate") < 50)
      .groupBy("route")
      .agg(avg("occupancy_rate").alias("avg_occupancy"))
      .orderBy("avg_occupancy")
      .limit(5)
    Load.writeToPostgres(underutilized, "underutilized_routes")
    Load.writeToParquet(underutilized, "output/underutilized_routes")

    // Overcrowded routes
    val overcrowded = enrichedDF.filter(col("occupancy_rate") > 90)
      .groupBy("route")
      .agg(avg("occupancy_rate").alias("avg_occupancy"))
      .orderBy(desc("avg_occupancy"))
      .limit(5)
    Load.writeToPostgres(overcrowded, "overcrowded_routes")
    Load.writeToParquet(overcrowded, "output/overcrowded_routes")

    println("Modular ETL pipeline completed. Data written to PostgreSQL and Parquet.")
    spark.stop()
  }
}