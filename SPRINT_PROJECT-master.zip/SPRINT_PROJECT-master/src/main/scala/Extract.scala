
import org.apache.spark.sql.{SparkSession}
import org.apache.spark.sql.types._

object Extract {
  def extractData(spark: SparkSession, filePath: String) = {
    val schema = StructType(Array(
      StructField("bus_id", StringType, true),
      StructField("route", StringType, true),
      StructField("bus_type", StringType, true),
      StructField("depot", StringType, true),
      StructField("date", StringType, true),
      StructField("capacity", IntegerType, true),
      StructField("passengers", IntegerType, true),
      StructField("occupancy_rate", DoubleType, true),
      StructField("distance_km", DoubleType, true),
      StructField("fare_per_passenger", DoubleType, true),
      StructField("revenue", DoubleType, true),
      StructField("fuel_consumed_liters", DoubleType, true),
      StructField("month", StringType, true),
      StructField("day_of_week", StringType, true)
    ))

    spark.read.option("header", "true").schema(schema).csv(filePath)
  }
}
