import org.apache.spark.sql.{DataFrame, SaveMode}
import java.util.Properties

object Load {
  val jdbcUrl = "jdbc:postgresql://localhost:5432/transportdb"
  val connectionProperties = new Properties()
  connectionProperties.setProperty("user", "postgres")
  connectionProperties.setProperty("password", "Tarun8309@main@")
  connectionProperties.setProperty("driver", "org.postgresql.Driver")

  // Write to PostgreSQL
  def writeToPostgres(df: DataFrame, tableName: String): Unit = {
    df.write
      .mode(SaveMode.Overwrite)
      .jdbc(jdbcUrl, tableName, connectionProperties)
  }

  // Write to Parquet
  def writeToParquet(df: DataFrame, outputPath: String): Unit = {
    df.write
      .mode(SaveMode.Overwrite)
      .parquet(outputPath)
  }
}